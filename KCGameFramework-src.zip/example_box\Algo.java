import java.io.BufferedReader;
import java.io.FileReader;

/**
 * 示例 Java 算法：读取扩展包中的 data.txt，计算数字平均值。
 * C 框架会根据 manifest.json 中的 "algo" 字段调用：
 *     java -jar algo.jar <扩展包目录>
 */
public class Algo {
    public static void main(String[] args) {
        String dir = args.length > 0 ? args[0] : ".";
        String path = dir + "/assets/data.txt";

        System.out.println("[JAVA] KC Demo 算法启动");
        System.out.println("[JAVA] 读取数据: " + path);

        double sum = 0;
        int count = 0;
        try (BufferedReader br = new BufferedReader(new FileReader(path))) {
            String line;
            while ((line = br.readLine()) != null) {
                line = line.trim();
                if (line.isEmpty()) continue;
                try {
                    sum += Double.parseDouble(line);
                    count++;
                } catch (NumberFormatException e) {
                    System.out.println("[JAVA] 跳过非数字行: " + line);
                }
            }
        } catch (Exception e) {
            System.err.println("[JAVA] 读取失败: " + e.getMessage());
            System.exit(1);
        }

        if (count == 0) {
            System.out.println("[JAVA] 没有有效数据。");
        } else {
            System.out.printf("[JAVA] 共 %d 个数字，平均值: %.2f%n", count, sum / count);
        }
    }
}
