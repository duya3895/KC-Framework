#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include "kcbox.h"

#ifdef _WIN32
#include <windows.h>
#include <direct.h>
#define KC_MKDIR(path) _mkdir(path)
#else
#include <dirent.h>
#include <unistd.h>
#define KC_MKDIR(path) mkdir(path, 0755)
#endif

static int file_exists(const char* path) {
    struct stat st;
    return stat(path, &st) == 0;
}

static int dir_exists(const char* path) {
    struct stat st;
    return (stat(path, &st) == 0) && ((st.st_mode & S_IFDIR) != 0);
}

int kc_scan_boxes(const char* kc_dir, KCBox boxes[], int max_boxes) {
    int count = 0;

    if (!dir_exists(kc_dir)) {
        fprintf(stderr, "[KC] 目录不存在，正在创建: %s\n", kc_dir);
        KC_MKDIR(kc_dir);
        return 0;
    }

#ifdef _WIN32
    char pattern[KC_MAX_PATH];
    snprintf(pattern, sizeof(pattern), "%s\\*.KCbox", kc_dir);
    WIN32_FIND_DATAA fd;
    HANDLE h = FindFirstFileA(pattern, &fd);
    if (h == INVALID_HANDLE_VALUE) return 0;
    do {
        if (count >= max_boxes) break;
        snprintf(boxes[count].path, sizeof(boxes[count].path), "%s\\%s", kc_dir, fd.cFileName);
        boxes[count].loaded = 0;
        count++;
    } while (FindNextFileA(h, &fd));
    FindClose(h);
#else
    DIR* d = opendir(kc_dir);
    if (!d) return 0;
    struct dirent* ent;
    while ((ent = readdir(d)) != NULL && count < max_boxes) {
        size_t len = strlen(ent->d_name);
        if (len > 6 && strcmp(ent->d_name + len - 6, ".KCbox") == 0) {
            snprintf(boxes[count].path, sizeof(boxes[count].path), "%s/%s", kc_dir, ent->d_name);
            boxes[count].loaded = 0;
            count++;
        }
    }
    closedir(d);
#endif

    return count;
}

int kc_extract_box(const KCBox* box, const char* out_dir) {
    if (!file_exists(box->path)) {
        fprintf(stderr, "[KC] 找不到文件: %s\n", box->path);
        return -1;
    }

    /* 使用 Python 标准库 zipfile 解压，跨平台且无需额外依赖 */
    char cmd[KC_MAX_PATH * 4];
    if (dir_exists(out_dir)) {
        /* 清空旧目录 */
#ifdef _WIN32
        snprintf(cmd, sizeof(cmd), "powershell -Command \"Remove-Item -Recurse -Force '%s'\"", out_dir);
#else
        snprintf(cmd, sizeof(cmd), "rm -rf '%s'", out_dir);
#endif
        system(cmd);
    }
    KC_MKDIR(out_dir);

    snprintf(cmd, sizeof(cmd),
             "python -c \"import zipfile, os; z=zipfile.ZipFile('%s'); z.extractall('%s'); z.close()\"",
             box->path, out_dir);
    int rc = system(cmd);
    if (rc != 0) {
        fprintf(stderr, "[KC] 解压失败，请确认已安装 Python。\n");
        return -1;
    }
    return 0;
}

static void parse_json_line(const char* line, KCBoxManifest* m) {
    char key[128], val[256];
    if (sscanf(line, " \"%127[^\"]\" : \"%255[^\"]\"", key, val) == 2 ||
        sscanf(line, "\"%127[^\"]\" : \"%255[^\"]\"", key, val) == 2) {
        if      (strcmp(key, "name") == 0) strcpy(m->name, val);
        else if (strcmp(key, "version") == 0) strcpy(m->version, val);
        else if (strcmp(key, "author") == 0) strcpy(m->author, val);
        else if (strcmp(key, "entry") == 0) { strcpy(m->entry, val); m->use_python = 1; }
        else if (strcmp(key, "algo") == 0) { strcpy(m->algo, val); m->use_java = 1; }
        else if (strcmp(key, "assets") == 0) strcpy(m->assets, val);
        else if (strcmp(key, "type") == 0) strcpy(m->box_type, val);
        else if (strcmp(key, "palette") == 0) strcpy(m->palette, val);
        else if (strcmp(key, "world_gen") == 0) strcpy(m->world_gen, val);
        else if (strcmp(key, "world_data") == 0) strcpy(m->world_data, val);
    }
}

int kc_read_manifest(const char* box_dir, KCBoxManifest* m) {
    memset(m, 0, sizeof(*m));
    strcpy(m->assets, "assets");

    char path[KC_MAX_PATH];
    snprintf(path, sizeof(path), "%s/manifest.json", box_dir);

    FILE* f = fopen(path, "r");
    if (!f) {
        fprintf(stderr, "[KC] 缺少 manifest.json: %s\n", path);
        return -1;
    }

    char line[512];
    while (fgets(line, sizeof(line), f)) {
        parse_json_line(line, m);
    }
    fclose(f);
    return 0;
}

int kc_run_box(const KCBox* box) {
    char cmd[KC_MAX_PATH * 4];
    int rc = 0;

    if (box->manifest.use_python && strlen(box->manifest.entry) > 0) {
        snprintf(cmd, sizeof(cmd), "python \"%s/%s\" \"%s\"",
                 box->extracted_to, box->manifest.entry, box->extracted_to);
        printf("[KC] 运行 Python 入口: %s\n", box->manifest.entry);
        rc = system(cmd);
    }

    if (box->manifest.use_java && strlen(box->manifest.algo) > 0) {
        snprintf(cmd, sizeof(cmd), "java -jar \"%s/%s\" \"%s\"",
                 box->extracted_to, box->manifest.algo, box->extracted_to);
        printf("[KC] 运行 Java 算法: %s\n", box->manifest.algo);
        rc = system(cmd);
    }

    return rc;
}


int kc_run_world_gen(const KCBox* box, int seed) {
    char cmd[KC_MAX_PATH * 4];
    int rc = 0;
    const char* assets = box->manifest.assets[0] ? box->manifest.assets : "assets";
    const char* wgen = box->manifest.world_gen[0] ? box->manifest.world_gen : "world_gen.py";
    const char* wdata = box->manifest.world_data[0] ? box->manifest.world_data : "world.dat";

    if (box->manifest.use_java && strlen(box->manifest.algo) > 0) {
        snprintf(cmd, sizeof(cmd), "java -jar \"%s/%s\" \"%s\" %d",
                 box->extracted_to, box->manifest.algo, box->extracted_to, seed);
        printf("[KC] 运行 Java 算法（世界参数）: %s\n", box->manifest.algo);
        rc = system(cmd);
    }

    snprintf(cmd, sizeof(cmd),
             "python \"%s/%s\" \"%s\" %d \"%s/%s/%s\"",
             box->extracted_to, wgen, box->extracted_to, seed,
             box->extracted_to, assets, wdata);
    printf("[KC] 运行世界生成: %s (seed=%d)\n", wgen, seed);
    rc = system(cmd);
    return rc;
}
