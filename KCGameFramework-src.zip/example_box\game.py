#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
示例玩法脚本：猜数字小游戏
C 框架加载扩展包后会执行本脚本。
脚本接收一个参数：扩展包解压后的目录路径。
"""

import random
import sys


def main():
    box_dir = sys.argv[1] if len(sys.argv) > 1 else "."
    print(f"[PY] 扩展包目录: {box_dir}")
    print("[PY] 欢迎来到 KC Demo 猜数字游戏！")

    secret = random.randint(1, 100)
    attempts = 0
    max_attempts = 7

    print(f"[PY] 我想好了 1~100 之间的一个数字，你有 {max_attempts} 次机会。")

    while attempts < max_attempts:
        try:
            guess = int(input("[PY] 请输入你的猜测: "))
        except ValueError:
            print("[PY] 请输入有效整数。")
            continue

        attempts += 1
        if guess < secret:
            print("[PY] 太小了！")
        elif guess > secret:
            print("[PY] 太大了！")
        else:
            print(f"[PY] 恭喜你，猜对了！答案就是 {secret}，用了 {attempts} 次。")
            return 0

    print(f"[PY] 机会用完了，正确答案是 {secret}。")
    return 1


if __name__ == "__main__":
    sys.exit(main())
