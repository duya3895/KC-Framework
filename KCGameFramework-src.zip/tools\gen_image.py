#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
简易 PPM 图片生成器
用于为 KC Game Framework 快速生成测试资源图片。
支持生成：渐变、棋盘、角色、随机噪声等。
输出格式：P3 (ASCII) 或 P6 (二进制)。
"""

import argparse
import math
import random


def save_ppm(path, pixels, width, height, binary=False):
    """把 RGB 像素列表保存为 PPM 文件。"""
    mode = "P6" if binary else "P3"
    with open(path, "wb" if binary else "w", encoding=None if binary else "utf-8") as f:
        f.write(f"{mode}\n{width} {height}\n255\n".encode() if binary else f"{mode}\n{width} {height}\n255\n")
        for y in range(height):
            for x in range(width):
                r, g, b = pixels[y * width + x]
                if binary:
                    f.write(bytes([r, g, b]))
                else:
                    f.write(f"{r} {g} {b} ".encode() if binary else f"{r} {g} {b} ")
            if not binary:
                f.write("\n")


def gradient(width, height):
    """水平彩虹渐变。"""
    pixels = []
    for y in range(height):
        for x in range(width):
            r = int(255 * x / max(width - 1, 1))
            g = int(255 * y / max(height - 1, 1))
            b = int(255 * (1 - x / max(width - 1, 1)))
            pixels.append((r, g, b))
    return pixels


def checkerboard(width, height, size=32):
    """棋盘格。"""
    pixels = []
    for y in range(height):
        for x in range(width):
            c = 200 if ((x // size) + (y // size)) % 2 == 0 else 50
            pixels.append((c, c, c))
    return pixels


def smiley(width, height):
    """笑脸图标。"""
    pixels = []
    cx, cy = width // 2, height // 2
    radius = min(cx, cy) - 4
    for y in range(height):
        for x in range(width):
            dx, dy = x - cx, y - cy
            dist = math.hypot(dx, dy)
            if dist < radius:
                # 黄色脸
                r, g, b = 255, 220, 0
                # 眼睛
                if abs(dx - radius // 3) < radius // 8 and abs(dy + radius // 6) < radius // 8:
                    r, g, b = 0, 0, 0
                if abs(dx + radius // 3) < radius // 8 and abs(dy + radius // 6) < radius // 8:
                    r, g, b = 0, 0, 0
                # 嘴巴
                if dy > radius // 6 and abs(math.hypot(dx, dy - radius // 4) - radius // 2) < radius // 10:
                    r, g, b = 0, 0, 0
            else:
                r, g, b = 30, 30, 60
            pixels.append((r, g, b))
    return pixels


def noise(width, height, seed=None):
    """随机噪声。"""
    rng = random.Random(seed)
    return [(rng.randint(0, 255), rng.randint(0, 255), rng.randint(0, 255))
            for _ in range(width * height)]


def palette(width, height):
    """KC Block World 调色板（每个像素 = 一个方块 ID 的颜色）。

    颜色顺序与 C 端 BLOCK_* 枚举保持一致：
        0  AIR / sky
        1  GRASS  草
        2  DIRT   土
        3  STONE  石头
        4  WATER  水
        5  SAND   沙
        6  SNOW   雪
        7  TREE   树干
        8  LEAVES 树叶
        9  BEDROCK 基岩
       10  LAVA   岩浆
    """
    colors = [
        (135, 206, 235),  # AIR / sky
        (124, 252,   0),  # GRASS
        (139,  90,  43),  # DIRT
        (128, 128, 128),  # STONE
        ( 30, 144, 255),  # WATER
        (244, 220, 140),  # SAND
        (255, 250, 250),  # SNOW
        (101,  67,  33),  # TREE
        ( 34, 139,  34),  # LEAVES
        ( 50,  50,  50),  # BEDROCK
        (255, 100,   0),  # LAVA
    ]
    pixels = []
    for y in range(height):
        for x in range(width):
            idx = y * width + x
            if idx < len(colors):
                pixels.append(colors[idx])
            else:
                # 超出部分用纯黑填充
                pixels.append((0, 0, 0))
    return pixels


def main():
    parser = argparse.ArgumentParser(description="生成简易 PPM 图片")
    parser.add_argument("-o", "--output", default="logo.ppm", help="输出文件路径")
    parser.add_argument("-W", "--width", type=int, default=128, help="图片宽度")
    parser.add_argument("-H", "--height", type=int, default=128, help="图片高度")
    parser.add_argument("-t", "--type", default="smiley",
                        choices=["gradient", "checkerboard", "smiley", "noise", "palette"],
                        help="图片类型")
    parser.add_argument("-b", "--binary", action="store_true", help="输出 P6 二进制格式")
    args = parser.parse_args()

    generators = {
        "gradient": gradient,
        "checkerboard": checkerboard,
        "smiley": smiley,
        "noise": noise,
        "palette": palette,
    }
    pixels = generators[args.type](args.width, args.height)
    save_ppm(args.output, pixels, args.width, args.height, binary=args.binary)
    print(f"[GEN] 已生成 {args.width}x{args.height} PPM 图片: {args.output}")


if __name__ == "__main__":
    main()
