﻿#include "world.h"
#include <stdio.h>
#include <string.h>

static int wrap_x(int x) {
    int r = x % WORLD_WIDTH;
    if (r < 0) r += WORLD_WIDTH;
    return r;
}

void world_init_empty(World* w, int seed) {
    w->seed = seed;
    w->loaded = 0;
    memset(w->blocks, 0, sizeof(w->blocks));
    for (int x = 0; x < WORLD_WIDTH; x++)
        w->ground[x] = 0;
}

int world_load_from_file(World* w, const char* path) {
    FILE* f = fopen(path, "rb");
    if (!f) return -1;

    uint32_t magic = 0, version = 0;
    int32_t seed = 0, width = 0, depth = 0;

    if (fread(&magic, 4, 1, f) != 1 ||
        fread(&version, 4, 1, f) != 1 ||
        fread(&seed, 4, 1, f) != 1 ||
        fread(&width, 4, 1, f) != 1 ||
        fread(&depth, 4, 1, f) != 1) {
        fclose(f);
        return -1;
    }

    if (magic != KC_WORLD_MAGIC || version != KC_WORLD_VERSION ||
        width != WORLD_WIDTH || depth != WORLD_DEPTH) {
        fclose(f);
        return -1;
    }

    if (fread(w->blocks, 1, (size_t)(WORLD_WIDTH * WORLD_DEPTH), f) !=
        (size_t)(WORLD_WIDTH * WORLD_DEPTH)) {
        fclose(f);
        return -1;
    }

    for (int x = 0; x < WORLD_WIDTH; x++) {
        int32_t h = 0;
        if (fread(&h, 4, 1, f) != 1) {
            fclose(f);
            return -1;
        }
        w->ground[x] = (int)h;
    }

    w->seed = (int)seed;
    w->loaded = 1;
    fclose(f);
    return 0;
}

void world_rebuild_ground(World* w) {
    for (int x = 0; x < WORLD_WIDTH; x++) {
        int top = 0;
        for (int y = WORLD_DEPTH - 1; y >= 0; y--) {
            unsigned char b = w->blocks[y * WORLD_WIDTH + x];
            if (world_is_solid(b)) {
                top = y;
                break;
            }
        }
        w->ground[x] = top;
    }
}

int world_get_ground(const World* w, int x) {
    return w->ground[wrap_x(x)];
}

int world_is_solid(unsigned char b) {
    return b != BLOCK_AIR && b != BLOCK_WATER && b != BLOCK_LAVA;
}

unsigned char world_get_block(const World* w, int x, int y) {
    if (y < 0) return BLOCK_BEDROCK;
    if (y >= WORLD_DEPTH) return BLOCK_AIR;
    return w->blocks[y * WORLD_WIDTH + wrap_x(x)];
}

void world_set_block(World* w, int x, int y, unsigned char b) {
    if (y < 0 || y >= WORLD_DEPTH) return;
    w->blocks[y * WORLD_WIDTH + wrap_x(x)] = b;
}

int world_block_pickable(unsigned char b) {
    return b != BLOCK_AIR && b != BLOCK_BEDROCK && b != BLOCK_WATER && b != BLOCK_LAVA;
}
