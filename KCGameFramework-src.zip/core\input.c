#include "input.h"

#ifdef _WIN32
#include <conio.h>
/* TCC 没有 conio.h 内置，需要静态链接 msvcrt。TCC 默认链 msvcrt。 */

void input_init(void) {
    /* msvcrt 不需要初始化；终端模式由 render_init 设为原始 */
}

int input_poll(void) {
    if (!_kbhit()) return KEY_NONE;
    int c = _getch();
    /* 方向键 / 功能键会先发 0xE0 或 0x00 */
    if (c == 0xE0 || c == 0x00) {
        c = _getch();
        switch (c) {
            case 72: return KEY_JUMP;        /* Up */
            case 80: return KEY_DOWN;        /* Down */
            case 75: return KEY_LEFT;        /* Left */
            case 77: return KEY_RIGHT;       /* Right */
        }
        return KEY_NONE;
    }
    switch (c) {
        case 'a': case 'A': return KEY_LEFT;
        case 'd': case 'D': return KEY_RIGHT;
        case 'w': case 'W': return KEY_JUMP;
        case 's': case 'S': return KEY_DOWN;
        case ' ':           return KEY_JUMP;
        case 'f': case 'F': return KEY_PLACE;
        case 'g': case 'G': return KEY_BREAK;
        case 'q': case 'Q': return KEY_QUIT;
        case 27:            return KEY_QUIT;       /* ESC */
        case '1':           return KEY_1;
        case '2':           return KEY_2;
        case '3':           return KEY_3;
        case '4':           return KEY_4;
        case '5':           return KEY_5;
    }
    return KEY_NONE;
}

#else  /* POSIX: 暂留简化版本，先聚焦 Windows */
#include <termios.h>
#include <unistd.h>
#include <fcntl.h>

static struct termios g_old_tio;

void input_init(void) {
    struct termios t;
    tcgetattr(STDIN_FILENO, &t);
    g_old_tio = t;
    t.c_lflag &= ~(ICANON | ECHO);
    tcsetattr(STDIN_FILENO, TCSANOW, &t);
}

int input_poll(void) {
    struct termios t;
    int oldf;
    tcgetattr(STDIN_FILENO, &t);
    oldf = fcntl(STDIN_FILENO, F_GETFL, 0);
    fcntl(STDIN_FILENO, F_SETFL, oldf | O_NONBLOCK);

    int ch = getchar();

    fcntl(STDIN_FILENO, F_SETFL, oldf);

    if (ch == EOF) return KEY_NONE;
    /* 简单 ESC 序列处理 */
    if (ch == 27) {
        int c2 = getchar();
        if (c2 == EOF) return KEY_QUIT;
        if (c2 == '[') {
            int c3 = getchar();
            switch (c3) {
                case 'A': return KEY_JUMP;
                case 'B': return KEY_DOWN;
                case 'C': return KEY_RIGHT;
                case 'D': return KEY_LEFT;
            }
        }
        return KEY_QUIT;
    }
    switch (ch) {
        case 'a': case 'A': return KEY_LEFT;
        case 'd': case 'D': return KEY_RIGHT;
        case 'w': case 'W': return KEY_JUMP;
        case 's': case 'S': return KEY_DOWN;
        case ' ':           return KEY_JUMP;
        case 'f': case 'F': return KEY_PLACE;
        case 'g': case 'G': return KEY_BREAK;
        case 'q': case 'Q': return KEY_QUIT;
        case '1': return KEY_1;
        case '2': return KEY_2;
        case '3': return KEY_3;
        case '4': return KEY_4;
        case '5': return KEY_5;
    }
    return KEY_NONE;
}
#endif
