#include "game.h"
#include "render.h"
#include "input.h"
#include <stdio.h>
#include <string.h>

#define GRAVITY    1
#define JUMP_VEL   5
#define MAX_FALL   6

static void set_msg(Game* g, const char* s) {
    strncpy(g->message, s, sizeof(g->message) - 1);
    g->message[sizeof(g->message) - 1] = 0;
    g->message_timer = 40;
}

/* (x, y) 处的方块是否实心（对玩家碰撞） */
static int solid_at(World* w, int x, int y) {
    if (y < 0) return 1;             /* 世界底按基岩 */
    if (y >= WORLD_DEPTH) return 0;  /* 天上为空气 */
    return world_is_solid(world_get_block(w, x, y));
}

void game_init(Game* g, World* w) {
    g->world = w;
    g->player.x = WORLD_WIDTH / 4;
    g->player.y = world_get_ground(w, g->player.x) + 1;
    g->player.vx = 0;
    g->player.vy = 0;
    g->player.on_ground = 1;
    g->player.facing = 1;
    g->player.inventory = BLOCK_DIRT;
    memset(g->player.collected, 0, sizeof(g->player.collected));
    g->running = 1;
    g->message_timer = 0;
    g->message[0] = 0;
    set_msg(g, "A/D move  W/Space jump  G dig  F build  1-5 select  Q quit");
}

void game_update(Game* g, int key) {
    Player* p = &g->player;
    World* w = g->world;

    /* --- 输入：移动 --- */
    p->vx = 0;
    if (key == KEY_LEFT)  { p->vx = -1; p->facing = -1; }
    if (key == KEY_RIGHT) { p->vx =  1; p->facing =  1; }
    if (key == KEY_JUMP && p->on_ground) {
        p->vy = JUMP_VEL;
        p->on_ground = 0;
    }

    /* --- 输入：交互（挖掘 / 放置） --- */
    if (key == KEY_BREAK) {
        int tx = p->x + p->facing;
        int ty = p->y - 1;
        unsigned char b = world_get_block(w, tx, ty);
        if (world_block_pickable(b)) {
            world_set_block(w, tx, ty, BLOCK_AIR);
            world_rebuild_ground(w);
            p->collected[b]++;
            set_msg(g, "Mined!");
        } else {
            set_msg(g, "Can't dig this");
        }
    }
    if (key == KEY_PLACE) {
        int tx = p->x + p->facing;
        int ty = p->y - 1;
        unsigned char cur = world_get_block(w, tx, ty);
        if (cur == BLOCK_AIR) {
            world_set_block(w, tx, ty, (unsigned char)p->inventory);
            world_rebuild_ground(w);
            set_msg(g, "Placed!");
        } else {
            set_msg(g, "Block in the way");
        }
    }

    /* --- 输入：选方块 --- */
    if (key == KEY_1) { p->inventory = BLOCK_DIRT;   set_msg(g, "Dirt"); }
    if (key == KEY_2) { p->inventory = BLOCK_STONE;  set_msg(g, "Stone"); }
    if (key == KEY_3) { p->inventory = BLOCK_GRASS;  set_msg(g, "Grass"); }
    if (key == KEY_4) { p->inventory = BLOCK_TREE;   set_msg(g, "Wood"); }
    if (key == KEY_5) { p->inventory = BLOCK_LEAVES; set_msg(g, "Leaves"); }

    if (key == KEY_QUIT) g->running = 0;

    /* --- 物理：重力 --- */
    p->vy -= GRAVITY;
    if (p->vy < -MAX_FALL) p->vy = -MAX_FALL;

    /* --- 物理：水平 --- */
    int nx = p->x + p->vx;
    if (p->vx != 0 && !solid_at(w, nx, p->y)) {
        p->x = nx;
    }

    /* --- 物理：垂直 --- */
    if (p->vy > 0) {
        /* 上升：检查头顶 */
        if (solid_at(w, p->x, p->y + 1)) {
            p->vy = 0;
        } else {
            p->y += p->vy;
            p->on_ground = 0;
        }
    } else if (p->vy < 0) {
        /* 下降：检查地面 */
        int ny = p->y + p->vy;
        int gy = world_get_ground(w, p->x);
        if (ny <= gy) {
            p->y = gy + 1;
            p->vy = 0;
            p->on_ground = 1;
        } else {
            p->y = ny;
            p->on_ground = 0;
        }
    } else {
        /* 静止：检查是否在地面 */
        int gy = world_get_ground(w, p->x);
        p->on_ground = (p->y == gy + 1);
    }

    /* --- 摄像机 --- */
    g->camera_x = p->x;
    g->camera_y = p->y + 2;     /* 摄像机略高于玩家，看到更多天空 */

    if (g->message_timer > 0) g->message_timer--;
}

void game_render(Game* g) {
    render_clear();
    World* w = g->world;
    Player* p = &g->player;
    int cx = g->camera_x;
    int cy = g->camera_y;

    /* 天空渐变色（按 y 高度） */
    int sky_top_r = 100, sky_top_g = 180, sky_top_b = 240;
    int sky_bot_r = 180, sky_bot_g = 220, sky_bot_b = 250;

    for (int sy = 0; sy < VIEW_H; sy++) {
        for (int sx = 0; sx < VIEW_W; sx++) {
            int wx = cx + sx - VIEW_W / 2;
            int wy = cy + (VIEW_H / 2 - sy);

            int r, gg, bb;
            char ch = ' ';
            if (wy >= 0 && wy < WORLD_DEPTH) {
                unsigned char bl = world_get_block(w, wx, wy);
                if (bl != BLOCK_AIR) {
                    RGB* rgb = &w->palette[bl];
                    r = rgb->r; gg = rgb->g; bb = rgb->b;
                    ch = '#';
                } else {
                    /* 天空：根据 wy 渐变 */
                    float t = wy / (float)WORLD_DEPTH;
                    r = (int)(sky_top_r * t + sky_bot_r * (1 - t));
                    gg = (int)(sky_top_g * t + sky_bot_g * (1 - t));
                    bb = (int)(sky_top_b * t + sky_bot_b * (1 - t));
                }
            } else {
                r = sky_top_r; gg = sky_top_g; bb = sky_top_b;
            }
            render_pixel(sx, sy, (unsigned char)r, (unsigned char)gg, (unsigned char)bb, ch);
        }
    }

    /* 玩家（一个 1x1 的方块，醒目色） */
    int p_sx = p->x - cx + VIEW_W / 2;
    int p_sy = VIEW_H / 2 - (p->y - cy);
    if (p_sx >= 0 && p_sx < VIEW_W && p_sy >= 0 && p_sy < VIEW_H) {
        render_pixel(p_sx, p_sy, 255, 230, 120, '@');
    }

    /* HUD */
    char hud[100];
    snprintf(hud, sizeof(hud), "X:%-5d Y:%-2d  Inv:%d  Q:quit",
             p->x, p->y, p->inventory);
    render_text(0, 0, hud, 255, 255, 255);

    /* 收集统计 */
    char stats[100];
    snprintf(stats, sizeof(stats), "Dirt:%d Stone:%d Grass:%d Wood:%d",
             p->collected[BLOCK_DIRT], p->collected[BLOCK_STONE],
             p->collected[BLOCK_GRASS], p->collected[BLOCK_TREE]);
    render_text(0, 1, stats, 200, 200, 200);

    if (g->message_timer > 0) {
        render_text(0, VIEW_H - 1, g->message, 255, 255, 0);
    }

    render_flush();
}
