#include "render.h"
#include <stdio.h>
#include <string.h>

#ifdef _WIN32
#include <windows.h>
/* 老版本 Windows SDK 可能没定义这个常量 */
#ifndef ENABLE_VIRTUAL_TERMINAL_PROCESSING
#define ENABLE_VIRTUAL_TERMINAL_PROCESSING 0x0004
#endif
#endif

/* 后台缓冲区：每个 cell 存字符 + RGB */
static char          g_cells[VIEW_H][VIEW_W];
static unsigned char g_r[VIEW_H][VIEW_W];
static unsigned char g_g[VIEW_H][VIEW_W];
static unsigned char g_b[VIEW_H][VIEW_W];
static int           g_dirty = 0;

void render_init(void) {
#ifdef _WIN32
    /* 启用 Windows 终端对 ANSI 转义序列的支持 */
    HANDLE h = GetStdHandle(STD_OUTPUT_HANDLE);
    DWORD mode = 0;
    if (GetConsoleMode(h, &mode)) {
        SetConsoleMode(h, mode | ENABLE_VIRTUAL_TERMINAL_PROCESSING);
    }
    /* 隐藏光标 */
    CONSOLE_CURSOR_INFO info;
    info.dwSize = 100;
    info.bVisible = FALSE;
    SetConsoleCursorInfo(h, &info);
#endif
    /* 清屏 + 切到备用屏幕（很多终端支持） */
    printf("\x1b[?1049h");      /* 进入备用屏幕 */
    printf("\x1b[2J\x1b[H");
    fflush(stdout);
    render_clear();
}

void render_done(void) {
    /* 还原光标 + 切回主屏幕 */
    printf("\x1b[0m");
#ifdef _WIN32
    HANDLE h = GetStdHandle(STD_OUTPUT_HANDLE);
    CONSOLE_CURSOR_INFO info;
    info.dwSize = 20;
    info.bVisible = TRUE;
    SetConsoleCursorInfo(h, &info);
#endif
    printf("\x1b[?1049l");      /* 离开备用屏幕 */
    fflush(stdout);
}

void render_clear(void) {
    for (int y = 0; y < VIEW_H; y++) {
        for (int x = 0; x < VIEW_W; x++) {
            g_cells[y][x] = ' ';
            g_r[y][x] = 0;
            g_g[y][x] = 0;
            g_b[y][x] = 0;
        }
    }
    g_dirty = 1;
}

void render_pixel(int x, int y, unsigned char r, unsigned char g, unsigned char b, char c) {
    if (x < 0 || x >= VIEW_W || y < 0 || y >= VIEW_H) return;
    g_cells[y][x] = c;
    g_r[y][x] = r;
    g_g[y][x] = g;
    g_b[y][x] = b;
    g_dirty = 1;
}

void render_text(int x, int y, const char* text,
                 unsigned char r, unsigned char g, unsigned char b) {
    for (int i = 0; text[i] && (x + i) < VIEW_W; i++) {
        render_pixel(x + i, y, r, g, b, text[i]);
    }
}

void render_flush(void) {
    if (!g_dirty) return;
    printf("\x1b[H");          /* 光标回到左上角 */
    for (int y = 0; y < VIEW_H; y++) {
        int last_r = -1, last_g = -1, last_b = -1;
        for (int x = 0; x < VIEW_W; x++) {
            if (g_r[y][x] != last_r || g_g[y][x] != last_g || g_b[y][x] != last_b) {
                printf("\x1b[38;2;%d;%d;%dm", g_r[y][x], g_g[y][x], g_b[y][x]);
                last_r = g_r[y][x];
                last_g = g_g[y][x];
                last_b = g_b[y][x];
            }
            putchar(g_cells[y][x]);
        }
        printf("\x1b[0m\n");
    }
    fflush(stdout);
    g_dirty = 0;
}
