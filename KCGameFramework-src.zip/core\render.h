#ifndef KC_RENDER_H
#define KC_RENDER_H

/* 24-bit ANSI 真彩色控制台渲染器（带双缓冲） */

#define VIEW_W 80
#define VIEW_H 24

void render_init(void);
void render_done(void);
void render_clear(void);
void render_pixel(int x, int y, unsigned char r, unsigned char g, unsigned char b, char c);
void render_text(int x, int y, const char* text,
                 unsigned char r, unsigned char g, unsigned char b);
void render_flush(void);

#endif
