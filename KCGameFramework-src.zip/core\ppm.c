#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "ppm.h"

int ppm_load(const char* path, PPMImage* img) {
    FILE* f = fopen(path, "rb");
    if (!f) return -1;

    char magic[3];
    if (fscanf(f, "%2s", magic) != 1) { fclose(f); return -1; }

    int maxval;
    if (fscanf(f, "%d %d %d", &img->width, &img->height, &maxval) != 3) {
        fclose(f); return -1;
    }

    int c = fgetc(f); /* 跳过空白 */
    (void)c;

    img->pixels = (unsigned char*)malloc(img->width * img->height * 3);
    if (!img->pixels) { fclose(f); return -1; }

    if (strcmp(magic, "P3") == 0) {
        for (int i = 0; i < img->width * img->height * 3; i++) {
            int v;
            fscanf(f, "%d", &v);
            img->pixels[i] = (unsigned char)(v * 255 / maxval);
        }
    } else if (strcmp(magic, "P6") == 0) {
        fread(img->pixels, 1, img->width * img->height * 3, f);
        if (maxval != 255) {
            for (int i = 0; i < img->width * img->height * 3; i++) {
                img->pixels[i] = (unsigned char)(img->pixels[i] * 255 / maxval);
            }
        }
    } else {
        free(img->pixels);
        fclose(f);
        return -1;
    }

    fclose(f);
    return 0;
}

void ppm_free(PPMImage* img) {
    if (img && img->pixels) {
        free(img->pixels);
        img->pixels = NULL;
    }
}

void ppm_render_console(const PPMImage* img, int target_width) {
    if (!img || !img->pixels || img->width <= 0 || img->height <= 0) return;

    int step = img->width / target_width;
    if (step < 1) step = 1;
    int tw = img->width / step;
    int th = img->height / (step * 2); /* 控制台字符高度约为宽度的 2 倍 */
    if (th < 1) th = 1;

    for (int y = 0; y < th; y++) {
        int py = y * step * 2;
        for (int x = 0; x < tw; x++) {
            int px = x * step;
            int i = (py * img->width + px) * 3;
            unsigned char r = img->pixels[i];
            unsigned char g = img->pixels[i + 1];
            unsigned char b = img->pixels[i + 2];
            int gray = (r + g + b) / 3;
            int idx = 232 + (gray * 23 / 255);
            printf("\x1b[38;5;%dm\u2588\x1b[0m", idx);
        }
        printf("\n");
    }
}
