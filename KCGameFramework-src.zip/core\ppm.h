#ifndef PPM_H
#define PPM_H

/* 极简 PPM (P3/P6) 图片读取器
 * Python 工具生成 P3 格式（ASCII RGB），C 框架可读取并渲染到控制台 */

typedef struct {
    int width;
    int height;
    unsigned char* pixels; /* RGBRGB... */
} PPMImage;

/* 加载 PPM 文件；返回 0 成功 */
int ppm_load(const char* path, PPMImage* img);

/* 释放图片内存 */
void ppm_free(PPMImage* img);

/* 在控制台以 256 色 ANSI 码渲染 */
void ppm_render_console(const PPMImage* img, int target_width);

#endif
