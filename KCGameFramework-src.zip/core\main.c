#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#ifdef _WIN32
#include <windows.h>
#define PATH_SEP "\\"
#else
#include <unistd.h>
#define PATH_SEP "/"
#endif

#include "kcbox.h"
#include "ppm.h"
#include "world.h"
#include "render.h"
#include "input.h"
#include "game.h"

/* ===== 默认调色板（KCbox 没自带 palette.ppm 时使用） ===== */
/* 注意：不要用 DEFAULT_PALETTE 名字，那是 Windows API 的宏 */
static const RGB KC_DEFAULT_BLOCK_PALETTE[BLOCK_COUNT] = {
    {135, 206, 235},  /* 0 AIR / sky */
    {124, 252,   0},  /* 1 GRASS 草 */
    {139,  90,  43},  /* 2 DIRT  土 */
    {128, 128, 128},  /* 3 STONE 石头 */
    { 30, 144, 255},  /* 4 WATER 水 */
    {244, 220, 140},  /* 5 SAND  沙 */
    {255, 250, 250},  /* 6 SNOW  雪 */
    {101,  67,  33},  /* 7 TREE  树干 */
    { 34, 139,  34},  /* 8 LEAVES 树叶 */
    { 50,  50,  50},  /* 9 BEDROCK 基岩 */
    {255, 100,   0},  /* 10 LAVA 岩浆 */
};

/* ===== 加载 KCbox 里的 palette.ppm ===== */
static int load_palette(World* w, const char* path) {
    for (int i = 0; i < BLOCK_COUNT; i++) w->palette[i] = KC_DEFAULT_BLOCK_PALETTE[i];
    if (!path || !*path) return -1;

    FILE* f = fopen(path, "rb");
    if (!f) return -1;

    char magic[3] = {0};
    if (fscanf(f, "%2s", magic) != 1) { fclose(f); return -1; }
    int ww, hh, maxv;
    if (fscanf(f, "%d %d %d", &ww, &hh, &maxv) != 3) { fclose(f); return -1; }
    int c = fgetc(f); (void)c;

    int n = ww * hh;
    if (n > BLOCK_COUNT) n = BLOCK_COUNT;

    if (magic[0] == 'P' && magic[1] == '6') {
        unsigned char* pixels = (unsigned char*)malloc(ww * hh * 3);
        if (!pixels) { fclose(f); return -1; }
        fread(pixels, 1, ww * hh * 3, f);
        for (int i = 0; i < n; i++) {
            w->palette[i].r = pixels[i * 3];
            w->palette[i].g = pixels[i * 3 + 1];
            w->palette[i].b = pixels[i * 3 + 2];
        }
        free(pixels);
    } else if (magic[0] == 'P' && magic[1] == '3') {
        for (int i = 0; i < n; i++) {
            int r, g, b;
            if (fscanf(f, "%d %d %d", &r, &g, &b) != 3) break;
            w->palette[i].r = r;
            w->palette[i].g = g;
            w->palette[i].b = b;
        }
    } else {
        fclose(f);
        return -1;
    }
    fclose(f);
    return 0;
}

/* ===== Sandbox 模式：方块世界 + 游戏循环 ===== */
static void run_sandbox(KCBox* box) {
    World world;
    int seed = (int)time(NULL);
    printf("[KC] 初始化空世界框架（种子 = %d）...\n", seed);
    world_init_empty(&world, seed);

    printf("[KC] 由 KCbox 扩展包生成世界地形...\n");
    if (kc_run_world_gen(box, seed) != 0) {
        fprintf(stderr, "[KC] 世界生成脚本执行失败。\n");
    }

    char world_path[KC_MAX_PATH];
    const char* wdata = box->manifest.world_data[0]
                        ? box->manifest.world_data
                        : "world.dat";
    snprintf(world_path, sizeof(world_path), "%s%s%s%s%s",
             box->extracted_to, PATH_SEP,
             box->manifest.assets[0] ? box->manifest.assets : "assets", PATH_SEP,
             wdata);

    if (world_load_from_file(&world, world_path) != 0) {
        fprintf(stderr, "[KC] 无法加载世界数据: %s\n", world_path);
        fprintf(stderr, "     请确认 manifest 中配置了 world_gen，且脚本生成了 world.dat。\n");
        return;
    }
    printf("[KC] 世界加载成功: %s\n", world_path);

    char palette_path[KC_MAX_PATH];
    const char* pfile = box->manifest.palette[0]
                        ? box->manifest.palette
                        : "palette.ppm";
    snprintf(palette_path, sizeof(palette_path), "%s%s%s%s%s",
             box->extracted_to, PATH_SEP,
             box->manifest.assets[0] ? box->manifest.assets : "assets", PATH_SEP,
             pfile);

    if (load_palette(&world, palette_path) == 0) {
        printf("[KC] 加载调色板: %s\n", palette_path);
    } else {
        printf("[KC] 未找到调色板，使用默认配色。\n");
    }

    Game game;
    game_init(&game, &world);

    render_init();
    input_init();

    while (game.running) {
        int key = input_poll();
        game_update(&game, key);
        game_render(&game);

#ifdef _WIN32
        Sleep(50);   /* ~20 FPS */
#else
        usleep(50000);
#endif
    }

    render_done();
    printf("\n[KC] 方块世界结束。再见！\n");
}

/* ===== Demo 模式：原来的渲染 logo + 跑 Python/Java ===== */
static void run_demo(KCBox* box) {
    char asset_path[KC_MAX_PATH];
    snprintf(asset_path, sizeof(asset_path), "%s%s%s%slogo.ppm",
             box->extracted_to, PATH_SEP,
             box->manifest.assets[0] ? box->manifest.assets : "assets", PATH_SEP);
    PPMImage logo;
    if (ppm_load(asset_path, &logo) == 0) {
        printf("\n[KC] 渲染扩展包图片 (%dx%d):\n", logo.width, logo.height);
        ppm_render_console(&logo, 64);
        ppm_free(&logo);
    } else {
        printf("\n[KC] 未找到 logo.ppm，跳过图片渲染。\n");
    }
    int rc = kc_run_box(box);
    printf("[KC] 扩展包执行结束（返回码: %d）。\n", rc);
}

int main(int argc, char* argv[]) {
    const char* kc_dir = "KC";
    if (argc > 1) kc_dir = argv[1];

    printf("========================================\n");
    printf("   KC Block World Framework\n");
    printf("========================================\n");
    printf("[KC] 扫描扩展目录: %s\n", kc_dir);

    KCBox boxes[KC_MAX_BOXES];
    int n = kc_scan_boxes(kc_dir, boxes, KC_MAX_BOXES);
    if (n == 0) {
        printf("[KC] 未发现任何 .KCbox 扩展包。\n");
        printf("     请将 zip 文件重命名为 .KCbox 并放入 %s 文件夹。\n", kc_dir);
        return 0;
    }

    printf("[KC] 发现 %d 个扩展包:\n", n);
    for (int i = 0; i < n; i++) printf("  [%d] %s\n", i + 1, boxes[i].path);

    /* 优先选择 type=sandbox 的 */
    int pick = 0;
    for (int i = 0; i < n; i++) {
        if (boxes[i].manifest.box_type[0] == 0) {
            /* 先解压读取 manifest 才能拿到 type，所以这里先按文件名简单过滤 */
            if (strstr(boxes[i].path, "PixelCraft") != NULL ||
                strstr(boxes[i].path, "sandbox") != NULL) {
                pick = i; break;
            }
        }
    }

    KCBox* box = &boxes[pick];
    snprintf(box->extracted_to, sizeof(box->extracted_to),
             "%s%s_extracted", kc_dir, PATH_SEP);

    printf("\n[KC] 正在加载扩展包: %s\n", box->path);
    if (kc_extract_box(box, box->extracted_to) != 0) {
        fprintf(stderr, "[KC] 加载失败。\n");
        return 1;
    }
    if (kc_read_manifest(box->extracted_to, &box->manifest) != 0) {
        fprintf(stderr, "[KC] 无法读取 manifest.json。\n");
        return 1;
    }

    /* 重新挑选：拿到 manifest 后再按 type 选 */
    if (strcmp(box->manifest.box_type, "sandbox") != 0) {
        for (int i = 0; i < n; i++) {
            if (i == pick) continue;
            if (boxes[i].manifest.box_type[0] == 0) {
                KCBox tmp = boxes[i];
                snprintf(tmp.extracted_to, sizeof(tmp.extracted_to),
                         "%s%s_extracted", kc_dir, PATH_SEP);
                if (kc_extract_box(&tmp, tmp.extracted_to) == 0 &&
                    kc_read_manifest(tmp.extracted_to, &tmp.manifest) == 0 &&
                    strcmp(tmp.manifest.box_type, "sandbox") == 0) {
                    box = &boxes[i];
                    break;
                }
            }
        }
    }

    printf("[KC] 扩展包信息:\n");
    printf("  名称:  %s\n", box->manifest.name[0] ? box->manifest.name : "未知");
    printf("  版本:  %s\n", box->manifest.version[0] ? box->manifest.version : "未知");
    printf("  作者:  %s\n", box->manifest.author[0] ? box->manifest.author : "未知");
    printf("  类型:  %s\n", box->manifest.box_type[0] ? box->manifest.box_type : "demo");
    printf("  调色板: %s\n", box->manifest.palette[0] ? box->manifest.palette : "(默认)");

    if (strcmp(box->manifest.box_type, "sandbox") == 0) {
        run_sandbox(box);
    } else {
        run_demo(box);
    }
    return 0;
}
