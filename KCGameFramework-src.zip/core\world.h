﻿#ifndef KC_WORLD_H
#define KC_WORLD_H

#include <stdint.h>

/* ============================================================
 * KC 方块世界（像素世界）
 *  - 框架只负责存储与渲染，不自带地形生成
 *  - 世界数据由 KCbox 扩展包（Python/Java）生成后加载
 *  - X 坐标：列方向，逻辑上"几乎无限"（8192 列 + 回绕）
 *  - Y 坐标：高度方向，0 在底部，向上递增
 * ============================================================ */

#define WORLD_WIDTH  8192
#define WORLD_DEPTH  48

#define KC_WORLD_MAGIC   0x4457434Bu
#define KC_WORLD_VERSION 1

enum {
    BLOCK_AIR = 0,
    BLOCK_GRASS,
    BLOCK_DIRT,
    BLOCK_STONE,
    BLOCK_WATER,
    BLOCK_SAND,
    BLOCK_SNOW,
    BLOCK_TREE,
    BLOCK_LEAVES,
    BLOCK_BEDROCK,
    BLOCK_LAVA,
    BLOCK_COUNT
};

typedef struct {
    unsigned char r, g, b;
} RGB;

typedef struct {
    RGB palette[BLOCK_COUNT];
    unsigned char blocks[WORLD_WIDTH * WORLD_DEPTH];
    int ground[WORLD_WIDTH];
    int seed;
    int loaded;
} World;

void world_init_empty(World* w, int seed);
int  world_load_from_file(World* w, const char* path);
int  world_get_ground(const World* w, int x);
int  world_is_solid(unsigned char b);
unsigned char world_get_block(const World* w, int x, int y);
void world_set_block(World* w, int x, int y, unsigned char b);
int  world_block_pickable(unsigned char b);
void world_rebuild_ground(World* w);

#endif
