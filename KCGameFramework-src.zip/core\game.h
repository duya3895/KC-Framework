#ifndef KC_GAME_H
#define KC_GAME_H

#include "world.h"

typedef struct {
    int x, y;            /* 位置 (x=列, y=脚底高度) */
    int vx, vy;          /* 速度 */
    int on_ground;
    int facing;          /* 朝向：-1 左 / +1 右 */
    int inventory;       /* 当前手持方块 */
    int collected[BLOCK_COUNT];
} Player;

typedef struct {
    World* world;
    Player player;
    int camera_x, camera_y;
    int running;
    int message_timer;
    char message[80];
} Game;

void game_init(Game* g, World* w);
void game_update(Game* g, int key);
void game_render(Game* g);

#endif
