# KC Game Framework

一个极简的“框架游戏”实现：
- **C 语言**：负责核心框架（扩展包扫描、解压、资源加载、渲染循环）。
- **Python**：生成简易 PPM 图片，并作为扩展包玩法脚本入口。
- **Java（可选）**：作为扩展包中的算法模块。
- **KCbox**：把 C + Python + Java 代码/资源打包成 zip，重命名为 `.KCbox`，放入 `KC` 文件夹即可被框架加载。

## 目录结构

```
KCGameFramework/
├── core/              # C 语言核心框架
│   ├── main.c         # 程序入口
│   ├── kcbox.c/h      # KCbox 扫描、解压、执行
│   └── ppm.c/h        # PPM 图片读取与控制台渲染
├── tools/             # Python 工具
│   ├── gen_image.py   # 生成 PPM 图片
│   └── pack_box.py    # 打包 KCbox
├── example_box/       # 示例扩展包源码
│   ├── manifest.json  # 扩展包配置
│   ├── game.py        # Python 玩法脚本
│   ├── Algo.java      # Java 算法源码
│   └── assets/        # 资源目录
│       ├── logo.ppm   # 扩展包图片
│       └── data.txt   # 算法数据
├── KC/                # 放入 .KCbox 扩展包
│   └── KCDemo.KCbox
├── build.bat          # Windows 一键构建
├── Makefile           # Linux / MinGW 构建
└── README.md          # 本文件
```

## 快速开始

### 1. 环境要求

- Windows / Linux
- `gcc`（C 编译器）
- `python`（Python 3）
- `javac` + `jar`（可选，用于 Java 算法示例）

### 2. 构建（Windows）

双击或在 PowerShell/CMD 中运行：

```bat
build.bat
```

构建完成后会生成 `kcgame.exe` 和 `KC\KCDemo.KCbox`。

### 3. 运行

```bat
kcgame.exe
```

程序会：
1. 扫描 `KC` 目录下的 `.KCbox` 文件。
2. 解压第一个扩展包到 `KC\_extracted`。
3. 读取 `manifest.json` 并显示扩展包信息。
4. 渲染 `assets/logo.ppm` 到控制台。
5. 依次执行 `game.py` 和 `algo.jar`。

### 4. 自定义扩展包

在 `example_box/` 基础上修改：

- `manifest.json`：配置名称、版本、入口脚本、算法包等。
- `game.py`：写你的 Python 玩法逻辑。
- `Algo.java`：写你的 Java 算法（可选）。
- `assets/`：放入 PPM 图片、数据文件等。

重新打包：

```bat
python tools\pack_box.py example_box -n 你的包名
```

然后把生成的 `KC\你的包名.KCbox` 放入 `KC` 文件夹即可。

## manifest.json 字段说明

| 字段 | 说明 |
|------|------|
| `name` | 扩展包名称 |
| `version` | 版本号 |
| `author` | 作者 |
| `assets` | 资源目录名，默认 `assets` |
| `entry` | Python 入口脚本，例如 `game.py` |
| `algo` | Java 算法 jar 包，例如 `algo.jar` |

## 生成图片

```bat
python tools\gen_image.py -o logo.ppm -t smiley -W 128 -H 128
```

支持的图片类型：`gradient`（渐变）、`checkerboard`（棋盘）、`smiley`（笑脸）、`noise`（噪声）。

## Linux / macOS

```bash
make
./kcgame
```

## 提示

- `.KCbox` 本质上就是 zip 文件，手动把 zip 重命名成 `.KCbox` 也可以。
- 想加载多个扩展包时，框架默认加载 `KC` 目录下第一个找到的 `.KCbox`。
- 可以把项目复制到你喜欢的地方运行；示例默认使用相对路径 `KC`。
