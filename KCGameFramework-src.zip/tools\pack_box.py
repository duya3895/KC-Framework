#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
KCbox 打包工具
把一个扩展包目录（内含 manifest.json、assets、game.py 等）打包成 zip，
并重命名为 .KCbox，放入 KC 文件夹。
"""

import argparse
import os
import shutil
import zipfile


def pack_box(source_dir, kc_dir="KC", output_name=None):
    source_dir = os.path.abspath(source_dir)
    kc_dir = os.path.abspath(kc_dir)
    os.makedirs(kc_dir, exist_ok=True)

    if not os.path.isdir(source_dir):
        raise ValueError(f"源目录不存在: {source_dir}")
    manifest = os.path.join(source_dir, "manifest.json")
    if not os.path.isfile(manifest):
        raise ValueError(f"缺少 manifest.json: {manifest}")

    if output_name is None:
        output_name = os.path.basename(source_dir.rstrip(os.sep))
    zip_path = os.path.join(kc_dir, f"{output_name}.zip")
    box_path = os.path.join(kc_dir, f"{output_name}.KCbox")

    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as zf:
        for root, _, files in os.walk(source_dir):
            for fn in files:
                full = os.path.join(root, fn)
                arc = os.path.relpath(full, source_dir)
                zf.write(full, arc)

    shutil.move(zip_path, box_path)
    print(f"[PACK] 已打包: {box_path}")
    return box_path


def main():
    parser = argparse.ArgumentParser(description="打包 KCbox 扩展包")
    parser.add_argument("source", help="扩展包源目录")
    parser.add_argument("-k", "--kc-dir", default="KC", help="KC 目录")
    parser.add_argument("-n", "--name", default=None, help="输出文件名（不含扩展名）")
    args = parser.parse_args()
    pack_box(args.source, args.kc_dir, args.name)


if __name__ == "__main__":
    main()
