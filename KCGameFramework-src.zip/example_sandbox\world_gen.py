#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
PixelCraft 世界生成脚本（KCbox 扩展包）

框架 C 引擎只负责渲染；地形由本脚本生成并写入 world.dat。
用法: python world_gen.py <box_dir> <seed> <output_path>

world.dat 二进制格式:
  magic   "KCWD" (4 bytes)
  version uint32 = 1
  seed    int32
  width   int32 = 8192
  depth   int32 = 48
  blocks  width*depth bytes
  ground  width * int32
"""

import os
import random
import struct
import sys

WORLD_WIDTH = 8192
WORLD_DEPTH = 48
KC_WORLD_MAGIC = 0x4457434B
KC_WORLD_VERSION = 1

BLOCK_AIR = 0
BLOCK_GRASS = 1
BLOCK_DIRT = 2
BLOCK_STONE = 3
BLOCK_WATER = 4
BLOCK_SAND = 5
BLOCK_SNOW = 6
BLOCK_TREE = 7
BLOCK_LEAVES = 8
BLOCK_BEDROCK = 9
BLOCK_LAVA = 10


def hash32(x: int) -> int:
    x = ((x >> 16) ^ x) * 0x45D9F3B & 0xFFFFFFFF
    x = ((x >> 16) ^ x) * 0x45D9F3B & 0xFFFFFFFF
    x = (x >> 16) ^ x
    return x & 0xFFFFFFFF


def hash01(x: int) -> float:
    return (hash32(x) & 0xFFFFFF) / float(0xFFFFFF)


def lerp(a: float, b: float, t: float) -> float:
    return a + (b - a) * t


def smoothstep(t: float) -> float:
    return t * t * (3.0 - 2.0 * t)


def value_noise(x: float) -> float:
    xi = int(x // 1)
    xf = x - xi
    xf = smoothstep(xf)
    return lerp(hash01(xi), hash01(xi + 1), xf)


def octave_noise(x: float, octaves: int) -> float:
    total = 0.0
    amp = 1.0
    freq = 1.0
    s = 0.0
    for _ in range(octaves):
        s += value_noise(x * freq) * amp
        total += amp
        amp *= 0.5
        freq *= 2.0
    return s / total


def generate_world(seed: int):
    rng = random.Random(seed)
    blocks = bytearray(WORLD_WIDTH * WORLD_DEPTH)
    ground = [0] * WORLD_WIDTH

    for x in range(WORLD_WIDTH):
        n1 = octave_noise(x * 0.015, 4)
        n2 = octave_noise(x * 0.05 + 100, 2)
        n3 = octave_noise(x * 0.3 + 200, 2)
        h = 12 + int(n1 * 5) + int(n2 * 2) + int(n3)
        h = max(3, min(WORLD_DEPTH - 6, h))
        ground[x] = h

        for y in range(h + 1):
            if y == h:
                if h <= 4:
                    b = BLOCK_WATER
                elif h == 5:
                    b = BLOCK_SAND
                elif h < 9:
                    b = BLOCK_GRASS
                elif h < 13:
                    b = BLOCK_STONE
                else:
                    b = BLOCK_SNOW
            elif y == 0:
                b = BLOCK_BEDROCK
            elif y == 1:
                b = BLOCK_LAVA
            elif h - y < 3:
                b = BLOCK_DIRT
            else:
                b = BLOCK_STONE
            blocks[y * WORLD_WIDTH + x] = b

    for x in range(2, WORLD_WIDTH - 2):
        h = ground[x]
        if h < 8 or h > 11:
            continue
        if rng.randint(0, 255) > 200:
            continue
        has_neighbor = False
        for dx in range(-2, 3):
            nh = ground[x + dx]
            if 8 <= nh <= 11 and blocks[(nh + 1) * WORLD_WIDTH + (x + dx)] == BLOCK_TREE:
                has_neighbor = True
                break
        if has_neighbor:
            continue
        tree_h = 3 + (rng.randint(0, 1))
        for dy in range(1, tree_h + 1):
            y = h + dy
            if y < WORLD_DEPTH:
                blocks[y * WORLD_WIDTH + x] = BLOCK_TREE
        top = h + tree_h
        if top + 1 < WORLD_DEPTH:
            blocks[(top + 1) * WORLD_WIDTH + x] = BLOCK_LEAVES
            if x > 0:
                blocks[(top + 1) * WORLD_WIDTH + (x - 1)] = BLOCK_LEAVES
            if x < WORLD_WIDTH - 1:
                blocks[(top + 1) * WORLD_WIDTH + (x + 1)] = BLOCK_LEAVES
        if top + 2 < WORLD_DEPTH:
            blocks[(top + 2) * WORLD_WIDTH + x] = BLOCK_LEAVES

    return blocks, ground


def write_world_dat(path: str, seed: int, blocks: bytes, ground: list):
    os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
    with open(path, "wb") as f:
        f.write(struct.pack("<IIiii", KC_WORLD_MAGIC, KC_WORLD_VERSION, seed, WORLD_WIDTH, WORLD_DEPTH))
        f.write(blocks)
        for h in ground:
            f.write(struct.pack("<i", h))


def main():
    if len(sys.argv) < 4:
        print("用法: python world_gen.py <box_dir> <seed> <output_path>")
        return 1

    box_dir = sys.argv[1]
    seed = int(sys.argv[2])
    out_path = sys.argv[3]

    print(f"[PixelCraft] 生成世界 seed={seed} -> {out_path}")
    blocks, ground = generate_world(seed)
    write_world_dat(out_path, seed, bytes(blocks), ground)
    print(f"[PixelCraft] 完成: {WORLD_WIDTH}x{WORLD_DEPTH} 列, {len(ground)} ground")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
