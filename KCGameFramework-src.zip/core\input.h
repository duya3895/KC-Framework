#ifndef KC_INPUT_H
#define KC_INPUT_H

/* 按键代码 */
enum {
    KEY_NONE = 0,
    KEY_LEFT,
    KEY_RIGHT,
    KEY_JUMP,
    KEY_DOWN,
    KEY_BREAK,
    KEY_PLACE,
    KEY_INVENTORY,
    KEY_1, KEY_2, KEY_3, KEY_4, KEY_5,
    KEY_QUIT
};

void input_init(void);
/* 非阻塞读取一个键，返回 KEY_* 常量；无键时返回 KEY_NONE */
int  input_poll(void);

#endif
