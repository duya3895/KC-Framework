@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion

echo ========================================
echo    KC Block World Framework - Build
echo ========================================

REM 选择编译器：优先 TCC（自带），否则 GCC
set CC=tcc\tcc\tcc.exe
if not exist "%CC%" (
    set CC=gcc
    where gcc >nul 2>nul
    if errorlevel 1 (
        echo [ERR] 未找到 tcc 也没有 gcc，请安装 MinGW/MSYS2/TCC。
        exit /b 1
    )
)
echo [BUILD] 编译器: %CC%

echo [BUILD] 编译 C 核心...
%CC% -o kcgame.exe core\main.c core\kcbox.c core\ppm.c core\world.c core\render.c core\input.c core\game.c
if errorlevel 1 (
    echo [ERR] 编译失败。
    exit /b 1
)
echo [BUILD] 编译完成: kcgame.exe

echo.
echo [BUILD] 生成 PixelCraft 调色板...
if not exist example_sandbox\assets mkdir example_sandbox\assets
python tools\gen_image.py -o example_sandbox\assets\palette.ppm -W 16 -H 1 -t palette
if errorlevel 1 (
    echo [WARN] 调色板生成失败，继续...
)

echo.
echo [BUILD] 打包 PixelCraft.KCbox...
python tools\pack_box.py example_sandbox -n PixelCraft
if errorlevel 1 (
    echo [WARN] 打包失败，继续...
)

echo.
echo ========================================
echo    构建完成！运行 kcgame.exe 开始游戏
echo ========================================
pause
