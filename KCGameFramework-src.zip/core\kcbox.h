#ifndef KCBOX_H
#define KCBOX_H

/* KCbox 加载器头文件
 * KCbox 本质上是一个改名的 zip 文件，里面包含：
 *   manifest.json   扩展包描述与启动配置
 *   assets/         资源目录（PPM 图片、调色板、数据等）
 *   game.py         Python 玩法脚本（可选）
 *   algo.jar        Java 算法包（可选）
 */

#define KC_MAX_PATH 512
#define KC_MAX_BOXES 32

typedef struct {
    char name[128];
    char version[32];
    char author[128];
    char entry[256];       /* 入口脚本，例如 "game.py" */
    char algo[256];        /* Java 算法包，例如 "algo.jar" */
    char assets[256];      /* 资源目录，默认 "assets" */
    char box_type[32];     /* 类型："sandbox" / "demo" / 其它 */
    char palette[256];     /* 调色板文件（相对 assets 目录） */
    char world_gen[256];   /* 世界生成脚本，例如 world_gen.py */
    char world_data[256];  /* 世界数据文件，默认 world.dat */
    int  use_python;       /* 是否调用 Python 入口 */
    int  use_java;         /* 是否调用 Java 算法 */
} KCBoxManifest;

typedef struct {
    char path[KC_MAX_PATH];
    char extracted_to[KC_MAX_PATH];
    KCBoxManifest manifest;
    int  loaded;
} KCBox;

/* 扫描 KC 目录，返回发现的 .KCbox 数量 */
int kc_scan_boxes(const char* kc_dir, KCBox boxes[], int max_boxes);

/* 使用 Python 解压脚本把一个 KCbox 解压到指定目录 */
int kc_extract_box(const KCBox* box, const char* out_dir);

/* 读取解压后的 manifest.json */
int kc_read_manifest(const char* box_dir, KCBoxManifest* manifest);

/* 运行扩展包 demo 流程（执行 Python 入口 + Java 算法） */
int kc_run_box(const KCBox* box);

/* 运行 sandbox 世界生成（Python world_gen + 可选 Java algo） */
int kc_run_world_gen(const KCBox* box, int seed);

#endif
