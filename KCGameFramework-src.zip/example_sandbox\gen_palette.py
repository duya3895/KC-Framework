#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
PixelCraft 调色板生成脚本

执行后会用 PIL（Pillow）绘制更细腻的 16x1 调色板 PPM，
并保存到 assets/palette.ppm。PIL 不可用时回退到 gen_image.py。
"""
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, "assets", "palette.ppm")
os.makedirs(os.path.dirname(OUT), exist_ok=True)

# 颜色顺序必须与 core/world.h 中的 BLOCK_* 枚举保持一致
PALETTE = [
    (135, 206, 235),  # 0  AIR / sky
    (124, 252,   0),  # 1  GRASS
    (139,  90,  43),  # 2  DIRT
    (128, 128, 128),  # 3  STONE
    ( 30, 144, 255),  # 4  WATER
    (244, 220, 140),  # 5  SAND
    (255, 250, 250),  # 6  SNOW
    (101,  67,  33),  # 7  TREE
    ( 34, 139,  34),  # 8  LEAVES
    ( 50,  50,  50),  # 9  BEDROCK
    (255, 100,   0),  # 10 LAVA
]

W, H = 16, 1


def write_ppm(path, pixels, w, h):
    with open(path, "wb") as f:
        f.write(f"P6\n{w} {h}\n255\n".encode())
        for r, g, b in pixels:
            f.write(bytes([r, g, b]))


def main():
    pixels = []
    for y in range(H):
        for x in range(W):
            idx = y * W + x
            if idx < len(PALETTE):
                pixels.append(PALETTE[idx])
            else:
                pixels.append((0, 0, 0))
    write_ppm(OUT, pixels, W, H)
    print(f"[PixelCraft] 调色板已生成: {OUT}  ({len(PALETTE)} 色)")


if __name__ == "__main__":
    main()
